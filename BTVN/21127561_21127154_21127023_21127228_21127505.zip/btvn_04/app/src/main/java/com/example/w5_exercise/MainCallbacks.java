package com.example.w5_exercise;

public interface MainCallbacks {
    public void onMsgFromFragToMain (String sender, String strValue);
}
