    package com.example.w5_exercise;

    public interface FragmentCallbacks {
        public void onMsgFromMainToFragment(String strValue);
    }
